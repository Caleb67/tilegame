using System;
using System.Collections.Generic;
using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.Tilemaps;

public class PlayerController : MonoBehaviour
{
    [Header("Player")]
    [SerializeField] float moveSpeed;

    [Header("Camera")]
    [SerializeField] float zoomSpeed;
    [SerializeField] float maxCameraSize;
    [SerializeField] float minCameraSize;
    [SerializeField] CinemachineCamera camera;

    Rigidbody2D body;
    

    void Start() {
        this.body = GetComponent<Rigidbody2D>();
    }
    void FixedUpdate() {
        var verticalAxis = Input.GetAxis("Vertical") * Time.deltaTime * this.moveSpeed;
        var horizontalAxis = Input.GetAxis("Horizontal") * Time.deltaTime * this.moveSpeed;
        
        this.body.linearVelocity = new Vector2(horizontalAxis, verticalAxis);
        //Camera.main.transform.Translate(horizontalAxisRaw, verticalAxisRaw, 0f);
    }

    void LateUpdate() {
        var scroll = Input.mouseScrollDelta;
        var sizeDifference = scroll.y * zoomSpeed;

        var prevSize = this.camera.Lens.OrthographicSize;
        var newSize = Math.Clamp(prevSize - sizeDifference, this.minCameraSize, this.maxCameraSize);
        this.camera.Lens.OrthographicSize = newSize;
    }

}
