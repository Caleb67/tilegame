using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

public class PlaceTile : MonoBehaviour
{
    [SerializeField] SpriteRenderer tilePreview;
    [SerializeField] Tilemap foregroundTilemap;
    [SerializeField] Tilemap backgroundTilemap;
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    [SerializeField] List<Tile> placeableTiles;

    [Header("Keybindings")]
    [SerializeField] KeyCode selectPrevTile;
    [SerializeField] KeyCode selectNextTile;
    [SerializeField] KeyCode switchToBackground;
    [SerializeField] KeyCode switchToForeground;

    int index = 0;
    Tilemap tilemap;

    void Start() {
        this.tilemap = foregroundTilemap;
    }

    void SelectPrevTile() {
        if (this.index <= 0) this.index = this.placeableTiles.Count - 1;
        else this.index -= 1;
    }
    void SelectNextTile() {
        if (this.index + 1 < this.placeableTiles.Count) this.index += 1;
        else this.index = 0;
    }

    Vector3 GetMouseWorld() {
        var mouseScreenPos = Input.mousePosition;
        mouseScreenPos.z = 0 - Camera.main.transform.position.z;
        return Camera.main.ScreenToWorldPoint(mouseScreenPos);
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetMouseButton(0)) PutTile();
        if (Input.GetMouseButton(1)) EraseTile();
        if (Input.GetMouseButton(2)) PickTile();

        if (Input.GetKeyDown(this.switchToBackground)) this.tilemap = this.backgroundTilemap;
        if (Input.GetKeyDown(this.switchToForeground)) this.tilemap = this.foregroundTilemap;


        if (Input.GetKeyDown(this.selectNextTile)) SelectNextTile();
        if (Input.GetKeyDown(this.selectPrevTile)) SelectPrevTile();

        this.transform.position = GetMouseWorld();
        this.tilePreview.sprite = this.placeableTiles[this.index].sprite;
    }
    
    void PutTile() {
        var mouseWorldPos = GetMouseWorld();
        var tilePos = this.tilemap.WorldToCell(mouseWorldPos);

        this.tilemap.SetTile(tilePos, this.placeableTiles[this.index]);
        //Debug.Log(tilePos);
    }

    void EraseTile() {
        var mouseWorldPos = GetMouseWorld();
        var tilePos = this.tilemap.WorldToCell(mouseWorldPos);

        this.tilemap.SetTile(tilePos, null);
    }

    void PickTile() {
        var mouseWorldPos = GetMouseWorld();
        var tilePos = this.tilemap.WorldToCell(mouseWorldPos);

        var tileBaseAtPos = this.tilemap.GetTile(tilePos);

        if (tileBaseAtPos is not Tile tileAtPos) return;
        var idx = this.placeableTiles.IndexOf(tileAtPos);
        if (idx == -1) return;
        this.index = idx;
    }

}
